// print hex/ASCII data
void prdata(unsigned char *ptr, unsigned char len,unsigned char raw);
// print module status
const unsigned char *prsts(unsigned char sts);
// print command response status
const unsigned char *prrst(unsigned char rst);
// print IEEE address
unsigned char *priaddr(unsigned char *addr);
// print short address
unsigned char *prsaddr(unsigned char *addr);


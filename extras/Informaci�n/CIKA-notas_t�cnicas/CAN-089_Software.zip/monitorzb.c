#include <stdio.h>

#include "apiframe.h"
#include "apicommon.h"
#include "apizb.h"
#include "monlib.h"
#include "monlibzb.h"


int efede;

int TX(unsigned char data)
{
}

int RX()
{
unsigned char c;
  
  if(read(efede,&c,1)<=0)  // wait for a char in serial input
    return(-1);
  else return(c);
}



main (int argc, char *argv[])
{

int ret;
static APIstruct api,apirx;
static APIdata rxdata;
APIinfo *info;
APIstatus *sts;
APIcommand *cmd;
APIresponse *resp;
APIrmtcmd *rcmd;
APIrmtrsp *rresp;
APIzsend *zs;
APIzsendsts *zssts;
APIzrecv *zr;
APIzxsend *zxs;
APIzxrecv *zxr;
APIziorecv *zior;
APIziorecvz *ziorz;
unsigned char escape;
int pspeed=0;


    if(argc!=4){
      fprintf(stderr,"usage: %s mode port speed\n",argv[0]);
      fprintf(stderr,"\tmode=1: escaped chars\n\tmode=0: non-escaped chars\n");
      exit (-1);
    }
    escape=(*argv[1]=='1');
    pspeed=atoi(argv[3]);
    if(pspeed){
      efede=set_up_comms(argv[2],pspeed,"none");
      /* disable buffering so we can see output in realtime */
      setvbuf(stdout,(char *)NULL,_IONBF,0);
    }
    else exit(-1);
    
  API_initgettingframe(&apirx);

  while(1){
    while((ret=API_getframe(&apirx,escape))<=0)
	sleep(1);
    rxdata.len=ret;
    memcpy(&rxdata.info,&apirx.frame.info,ret);
    API_initgettingframe(&apirx);
    info=&rxdata.info;
    printf("\nRX: ");
    prdata((unsigned char *)info,rxdata.len,1);
    printf("\n");
    switch(info->id){
    case API_APISTATUS:
      sts=(APIstatus *)&info->data;
      printf("Status frame: %s (%02X)\n",prsts(sts->status),sts->status);
      break;
    case API_APIQCOMMAND:
      printf("Queue ");
    case API_APICOMMAND:
      cmd=(APIcommand *)&info->data;
      printf("Command frame: ID: %02X CMD: %c%c PARAM: ",cmd->frameid,cmd->cmd[0],cmd->cmd[1]);
      prdata(&cmd->param,rxdata.len-4,0);
      printf("\n");
      break;
    case API_APIRESPONSE:
      resp=(APIresponse *)&info->data;
      printf("Command Response frame: ID: %02X STS: %s (%02X) DATA: ",resp->frameid,prrst(resp->status),resp->status);
      prdata(&resp->data,rxdata.len-5,0);
      printf("\n");
      break;
    case API_APIRMTCMD:
      rcmd=(APIrmtcmd *)&info->data;
      printf("Remote Command frame: ID: %02X\n",rcmd->frameid);
      priaddr(rcmd->addr64);
      prsaddr(rcmd->addr16);
      if(rcmd->options&RCO_APPLY)
	printf("\nAPPLY ");
      else
	printf("\n");
      printf("CMD: %c%c PARAM: ",rcmd->cmd[0],rcmd->cmd[1]);
      prdata(&rcmd->param,rxdata.len-4,0);
      printf("\n");
      break;
    case API_APIRMTRSP:
      rresp=(APIrmtrsp *)&info->data;
      printf("Remote Command Response frame: ID: %02X\n",resp->frameid);
      priaddr(rresp->addr64);
      prsaddr(rresp->addr16);
      printf("STS: %s (%02X) DATA: ",prrst(rresp->status),rresp->status);
      prdata(&rresp->data,rxdata.len-5,0);
      printf("\n");
      break;
    case API_APIZSEND:
      zs=(APIzsend *)&info->data;
      printf("Data Send, ID: %02X,",zs->frameid);
      priaddr(zs->addr64);
      prsaddr(zs->addr16);
      printf("\nRADIUS: %u OPT: %s (%02X) DATA: ",zs->radius,przsop(zs->options),zs->options);
      prdata(&zs->data,rxdata.len-14,0);
      printf("\n");
      break;
    case API_APIZXSEND:
      zxs=(APIzxsend *)&info->data;
      printf("Explicit Data Send, ID: %02X,",zs->frameid);
      priaddr(zxs->addr64);
      prsaddr(zxs->addr16);
      printf("\nSRC EP: %02X, DEST EP: %02X, PROFILE-ID: %02X%02X, CLUSTER-ID: %02X%02X",zxs->src_ep,zxs->dest_ep,zxs->profileID[0],zxs->profileID[1],zxs->clusterID[0],zxs->clusterID[1]);
      printf("\nRADIUS: %u OPT: %s (%02X) DATA: ",zxs->radius,przsop(zxs->options),zxs->options);
      prdata(&zxs->data,rxdata.len-20,0);
      printf("\n");
      break;
    case API_APIZSNDSTS:
      zssts=(APIzsendsts *)&info->data;
      printf("Send Status frame: ID: %02X DELIVERY STS: %s (%02X) DISCOVERY STS: %s (%02X)\n",zssts->frameid,przsst(zssts->delvsts),zssts->delvsts,przsst(zssts->discsts),zssts->discsts);
      break;
    case API_APIZRECV:
      zr=(APIzrecv *)&info->data;
      printf("Data Receive,");
      priaddr(zr->addr64);
      prsaddr(zr->addr16);
      printf("\nOPT: %s (%02X) DATA: ",przrop(zr->options),zr->options);
      prdata(&zr->data,rxdata.len-12,0);
      printf("\n");
      break;
    case API_APIZXRECV:
      zxr=(APIzxrecv *)&info->data;
      printf("Explicit Data Receive,");
      priaddr(zxr->addr64);
      prsaddr(zxr->addr16);
      printf("\nSRC EP: %02X, DEST EP: %02X, PROFILE-ID: %02X%02X, CLUSTER-ID: %02X%02X",zxr->src_ep,zxr->dest_ep,zxr->profileID[0],zxr->profileID[1],zxr->clusterID[0],zxr->clusterID[1]);
      printf("\nOPT: %s (%02X) DATA: ",przrop(zxr->options),zxr->options);
      prdata(&zxr->data,rxdata.len-18,0);
      printf("\n");
      break;
    case API_APIZIORECV:
      ziorz=(APIziorecvz *)&info->data;
      zior=&ziorz->data;
      printf("I/O Data Receive,");
      priaddr(ziorz->addr64);
      prsaddr(ziorz->addr16);
      printf("\nOPT: %s (%02X)\n",przrop(ziorz->options),ziorz->options);
      prziodata(zior);
      break;
    case API_APIZNODEID:
      printf("NODE ID NOT SUPPORTED YET");	     
      break;
    default:
      printf("*** UNKNOWN FRAME\n");
    }
    printf("\n");
  }
}




#include <stdio.h>

#include "apiframe.h"
#include "apicommon.h"
#include "apizb.h"
#include "monlib.h"
#include "monlibzb.h"

int efede;

int TX(unsigned char data)
{
  write(efede,&data,1);
  return(1);
}

int RX()
{
unsigned char c;
  
  if(read(efede,&c,1)<=0)  // wait for a char in serial input
    return(-1);
  else return(c);
}



main (int argc, char *argv[])
{

int ret=0;
static APIstruct api,apirx;
static APIdata rxdata;
APIinfo *info;
APIstatus *sts;
APIcommand *cmd;
APIresponse *resp;
APIznodeID *id;
unsigned char escape;
int pspeed=0;


    if(argc!=4){
      fprintf(stderr,"usage: %s mode port speed\n",argv[0]);
      fprintf(stderr,"\tmode=1: escaped chars\n\tmode=0: non-escaped chars\n");
      exit (-1);
    }
    escape=(*argv[1]=='1');
    pspeed=atoi(argv[3]);
    if(pspeed){
      efede=set_up_comms(argv[2],pspeed,"none");
      /* disable buffering so we can see output in realtime */
      setvbuf(stdout,(char *)NULL,_IONBF,0);
    }
    else exit(-1);
    
    api.frame.info.id=API_APICOMMAND;
    cmd=(APIcommand *)&api.frame.info.data;
    cmd->frameid=0x12;
    cmd->cmd[0]='N';
    cmd->cmd[1]='D';
    API_buildframe(&api,sizeof(APIcommand)+1-1);
    prdata((char *)&api.frame,api.len,1);
    API_initsendingframe(&api);
    while(API_sendframe(&api,0)==API_AGAIN);
    
  API_initgettingframe(&apirx);

  while(!ret){
    while((ret=API_getframe(&apirx,escape))<=0)
	sleep(1);
    rxdata.len=ret;
    memcpy(&rxdata.info,&apirx.frame.info,ret);
    API_initgettingframe(&apirx);
    info=&rxdata.info;
    printf("\nRX: ");
    prdata((unsigned char *)info,rxdata.len,1);
    printf("\n");
    switch(info->id){
    case API_APISTATUS:
      sts=(APIstatus *)&info->data;
      printf("Status frame: %s (%02X)\n",prsts(sts->status),sts->status);
      break;
    case API_APIQCOMMAND:
      printf("Queue ");
    case API_APICOMMAND:
      cmd=(APIcommand *)&info->data;
      printf("Command frame: ID: %02X CMD: %c%c PARAM: ",cmd->frameid,cmd->cmd[0],cmd->cmd[1]);
      prdata(&cmd->param,rxdata.len-4,0);
      printf("\n");
      break;
    case API_APIRESPONSE:
      resp=(APIresponse *)&info->data;
      printf("Command Response frame: ID: %02X STS: %s (%02X) DATA: ",resp->frameid,prrst(resp->status),resp->status);
      prdata(&resp->data,rxdata.len-5,0);
      printf("\n");
	ret=0;
      id=(APIznodeID *)&resp->data;
	prznodeid(id);
      break;
    default:
      ret=0;
    }
    printf("\n");
  }
}




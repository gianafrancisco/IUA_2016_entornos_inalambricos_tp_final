#include "apiframe.h"




void API_buildframe(APIstruct *api,unsigned char datalen)
{
register unsigned char aux,chksum,*ptr;

	api->frame.start=API_START;			// build frame: START
	ptr=(unsigned char*)&api->frame.info;		// calculate checksum
	chksum=0;
	aux=datalen;
	api->frame.len[0]=0;
	api->frame.len[1]=aux;
	while(aux--)     
		chksum+=*(ptr++);
	*(ptr)=~chksum;					// build frame: store checksum
	api->len=datalen+API_OVERHEAD;
}

int API_checkframe(APIstruct *api)
{
register unsigned char aux,chksum,*ptr;

  if(api->frame.start!=API_START)			// validate framing (start of frame)
    return(API_ERROR);
  chksum=0;
  aux=api->len-API_OVERHEAD;
  if(aux!=api->frame.len[1])
    return(API_ERROR);
  ptr=(unsigned char *)&api->frame.info;		// calculate checksum
  while(aux--)
    chksum+=*(ptr++);
  if(chksum+(*ptr)!=0xFF)
    return(API_ERROR);
  return(api->frame.len[1]);
}

static unsigned char sstate;

void API_initsendingframe(APIstruct *api)
{
	api->ptr=(unsigned char *)&api->frame;		// point to start of frame
	api->cnt=api->len;                              // number of bytes to transmit
	sstate=0;
}


int API_sendframe(APIstruct *api,unsigned char escape)
{
register unsigned char aux,*ptr,data;
register int busy;

  aux=api->cnt;
  ptr=api->ptr;
  do {
    data=*ptr;
    if(escape){
      switch(sstate){
      case 0:
	if(data==API_START){
	  if(aux!=api->len)
	    sstate=1;
	  else
	    break;
	}
	else {
	  if(data==API_ESCAPE || data==0x11 || data==0x13)
	    sstate=1;
	  else
	    break;
	}
      case 1:
	data=API_ESCAPE;
	break;
      case 2:
	data^=API_XOR;
	break;
      }
    }
    if((busy=TX(data))!= -1){
      switch(sstate){
      case 2:
	sstate=0;
      case 0:
	ptr++;
	if(--aux==0)			// done ?
	  return(API_DONE);
	break;
      case 1:
	sstate++;
	break;
      }
    }
  } while(busy!=-1);						// pump while there is room
  api->cnt=aux;
  api->ptr=ptr;
  return(API_AGAIN);
}

static unsigned char rstate;

void API_initgettingframe(APIstruct *api)
{
  api->ptr=(unsigned char *)&api->frame;		// point to start of frame
  api->cnt=0;						// number of bytes get so far
  rstate=0;
}

int API_getframe(APIstruct *api, unsigned char escape)
{
register unsigned char aux,*ptr,len;
register int ret,data;

  aux=api->cnt;
  ptr=api->ptr;
  while((data=RX())!=-1){				// wait if nothing comes out from the outside world
    switch(data){
    case API_ESCAPE:
      if(escape){
	rstate=1;
	break;
      }
    case API_START:				// reset string on start character
      if(escape){
	aux=0;
	ptr=(unsigned char *)&api->frame;
      }
    default:
      if(++aux>API_MAXFRAMESZ) {		// flush if too long			
	aux=0;
	ptr=(unsigned char *)&api->frame;
      }
      if(rstate){
	data^=API_XOR;
	rstate=0;
      }
      *(ptr++)=data;
      len=api->frame.len[1]+API_OVERHEAD;
      if((aux>API_LENOFFSET)&&(aux==len)){
	api->len=aux;
	if((ret=API_checkframe(api))==API_ERROR){
	  aux=0;
	  ptr=(unsigned char *)&api->frame;
	  rstate=0;
	}
	else
	  return(ret);
      }
      break;
    }
  }
  api->cnt=aux;
  api->ptr=ptr;
  return(API_AGAIN);
}


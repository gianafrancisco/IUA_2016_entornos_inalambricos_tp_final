#ifndef IODATA_H
#define IODATA_H

typedef struct {
	unsigned char data[2];
} IOdata;

#endif

// print send options
const unsigned char *przsop(unsigned char sop);
// print send status
const unsigned char *przsst(unsigned char sts);
// print receive options
unsigned char *przrop(unsigned char rop);
// print node type
unsigned char *przdt(unsigned char zdt);
// print I/O data
void prziodata(APIziorecv *io);
// print node ID
void prznodeid(APIznodeID *id);


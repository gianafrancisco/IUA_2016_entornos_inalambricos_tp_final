
// Should accomodate 100 bytes data packet + header overhead
#define APIBUFFERSZ	128


#define API_MAXFRAMESZ	APIBUFFERSZ

#define API_START	0x7E
#define API_ESCAPE	0x7D
#define API_XOR		0x20



//account for start, len, and checksum
#define API_OVERHEAD	4
//account for id
#define API_DATAOVH	(API_OVERHEAD+1)

typedef struct {
	unsigned char id;
	unsigned char data[API_MAXFRAMESZ-API_DATAOVH];
} APIinfo;

typedef struct {
	unsigned char start;
	unsigned char len[2];
	APIinfo info;
} APIframe;

#define API_LENOFFSET	2


typedef struct {
	unsigned char *ptr;
	unsigned char cnt;
	unsigned char len;
	APIframe frame;
} APIstruct;

typedef struct {
        unsigned char len;
	APIinfo info;
} APIdata;

// formats API frame in buffer
void API_buildframe(APIstruct *api,unsigned char datalen);

// validates frame in buffer, returns data len 
int API_checkframe(APIstruct *api);

// inits sending process, call before send loop (API_sendframe())
void API_initsendingframe(APIstruct *api);

#define API_DONE	1
#define API_AGAIN	0
#define API_ERROR	-1

/* send a frame (output bytes to TX() routine and escape characters)
returns API_DONE when done, API_AGAIN if need to call again
  if 'escape' is true, then special chars are escaped */
int API_sendframe(APIstruct *api, unsigned char escape);

// inits getting process, call before get loop (API_getframe())
void API_initgettingframe(APIstruct *API);

/* get a frame (collect bytes from RX() routine and correct escaped characters)
returns data lenght (>0) when done, API_AGAIN if need to call again.
    if 'escape' is true, then special chars are escaped 
If special chars are not escaped, idle line must be detected and API_initgettingframe()
must be called to sync with next frame. This is because in this mode 0x7E does not
automatically restart frame reception and any 'extra' byte or frame interruption
will cause de-synchronization
*/
int API_getframe(APIstruct *api, unsigned char escape);

/* return -1 if no buffer space (can't transmit), 0 if OK */
extern int TX(unsigned char);
/* return received char, -1 if no char available */
extern int RX(void);



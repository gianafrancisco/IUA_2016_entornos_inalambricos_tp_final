// frame types
#define API_APISTATUS	0x8A
#define API_APICOMMAND	0x08
#define API_APIQCOMMAND	0x09
#define API_APIRESPONSE	0x88
#define API_APIRMTCMD	0x17
#define API_APIRMTRSP	0x97


// module status
#define STS_HWRST	0
#define STS_WDRST	1
#define STS_ASSOC	2
#define STS_DISA	3
#define STS_SYNCLOST	4
#define STS_REALIGN	5
#define STS_RESTART	6

// remote command options
#define RCO_APPLY	0x02

// [remote] command response status
#define RST_OK		0
#define RST_ERROR	1
#define RST_INVCMD	2
#define RST_INVPARAM	3
#define RST_NORESPONSE	4


typedef struct {
	unsigned char status;
} APIstatus;

typedef struct {
	unsigned char frameid;
	unsigned char cmd[2];
	unsigned char param;
} APIcommand;

typedef struct {
	unsigned char frameid;
	unsigned char cmd[2];
	unsigned char status;
	unsigned char data;
} APIresponse;

typedef struct {
	unsigned char frameid;
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char options;
	unsigned char cmd[2];
	unsigned char param;
} APIrmtcmd;

typedef struct {
	unsigned char frameid;
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char cmd[2];
	unsigned char status;
	unsigned char data;
} APIrmtrsp;



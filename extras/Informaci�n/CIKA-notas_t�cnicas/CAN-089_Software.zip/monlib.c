#include "apicommon.h"

void prdata(unsigned char *ptr, unsigned char len,unsigned char raw)
{
int i;
unsigned char data;

  for(i=0;i<len;i++){
    data=*(ptr++);
    if(!raw && isprint(data))
      printf("%c(%02X) ",data,data);
    else
      printf("%02X ",data);
  }
}

const unsigned char *prsts(unsigned char sts)
{
static const char* stss[]={"HWRST","WDRST","ASSOC","DISA","SYNCLOST","REALIGN","RESTART"};

  if(sts<=STS_RESTART)
    return(stss[sts]);
  else
    return("?");
}

const unsigned char *prrst(unsigned char rst)
{
static const char* rsts[]={"OK","ERROR","INVALID_COMMAND","INVALID_PARAMETER","NO RESPONSE"};

  if(rst<=RST_INVPARAM)
    return(rsts[rst]);
  else
    return("?");
}

unsigned char *priaddr(unsigned char *addr)
{
        printf(" IEEE Addr: ");
	prdata(addr,8,1);
}

unsigned char *prsaddr(unsigned char *addr)
{
        printf(" Short Addr: ");
	prdata(addr,2,1);
}



// frame types
#define API_APIZSEND	0x10
#define API_APIZXSEND	0x11
#define API_APIZSNDSTS	0x8B
#define API_APIZRECV	0x90
#define API_APIZXRECV	0x91
#define API_APIZIORECV	0x92
#define API_APIZNODEID	0X95
// Boxed sensor, unsupported
#define API_APIZXBSENSOR	0x94


#define ADDR_ZUNKNOWN	{0xFF,0xFE}
#define ADDR_ZBCAST	{0,0,0,0,0,0,0xFF,0xFF}

// send options
#define ZSO_MCAST	0x08

// send status (delivery)
#define ZSS_SUCCESS	0x00
#define ZSS_CCAFAILURE	0x02
#define ZSS_INVDEP	0x15
#define ZSS_NOAPSACK	0x21
#define ZSS_NOTJOINED	0x22
#define ZSS_SELFADDR	0x23
#define ZSS_ADDRNF	0x24
#define ZSS_ROUTENF	0x25

// send status (discovery)
#define ZSD_NODISC	0x00
#define ZSD_ADDRDISC	0x01
#define ZSD_ROUTEDISC	0x02
#define ZSD_ARDISC	0x03

// receive options
#define ZRO_ACKSENT	0x01
#define ZRO_BCAST	0x02

// node type
#define ZID_DTCOORD	0x00
#define ZID_DTROUTER	0x01
#define ZID_DTENDDEV	0x02

typedef struct {
	unsigned char frameid;
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char radius;
	unsigned char options;
	unsigned char data;
} APIzsend;

typedef struct {
	unsigned char frameid;
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char src_ep;
	unsigned char dest_ep;
	unsigned char clusterID[2];
	unsigned char profileID[2];
	unsigned char radius;
	unsigned char options;
	unsigned char data;
} APIzxsend;

typedef struct {
	unsigned char frameid;
	unsigned char addr16[2];
	unsigned char retrycnt;
	unsigned char delvsts;
	unsigned char discsts;
} APIzsendsts;

typedef struct {
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char options;
	unsigned char data;
} APIzrecv;

typedef struct {
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char src_ep;
	unsigned char dest_ep;
	unsigned char clusterID[2];
	unsigned char profileID[2];
	unsigned char options;
	unsigned char data;
} APIzxrecv;

#include "IOdata.h"
typedef struct {
	unsigned char samples;
	unsigned char digchannel[2];
	unsigned char anchannel;
	IOdata iodata;
} APIziorecv;

typedef struct {
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char options;
	APIziorecv data;
} APIziorecvz;

typedef struct {
	unsigned char addr16[2];
	unsigned char addr64[8];
	unsigned char ID;
} APIznodeID1;

typedef struct {
	unsigned char parent[2];
	unsigned char type;
	unsigned char action;
	unsigned char profileID[2];
	unsigned char manufacturerID[2];
} APIznodeID2;

typedef struct {
	APIznodeID1 id1;
	APIznodeID2 id2;
} APIznodeID;

typedef struct {
	unsigned char frameid;
	unsigned char addr64[8];
	unsigned char addr16[2];
	unsigned char options;
	APIznodeID data;
} APIznodeIDz;




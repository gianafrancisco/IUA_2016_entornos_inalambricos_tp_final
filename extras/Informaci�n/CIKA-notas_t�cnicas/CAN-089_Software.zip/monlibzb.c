#include "apizb.h"

const unsigned char *przsop(unsigned char sop)
{

  switch(sop){
  case ZSO_MCAST:
    return("MULTICAST");
  case 0:
    return("NONE");
  default:
    return("?");
  }
}


const unsigned char *przsst(unsigned char sts)
{

  switch(sts){
  case ZSS_SUCCESS:
    return("SUCCESS");
  case ZSS_CCAFAILURE:
    return("CCA_FAILURE");
  default:
    return("?");
  }
}

unsigned char *przrop(unsigned char rop)
{
  switch(rop){
  case ZRO_ACKSENT:
    return("ACKED");
  case ZRO_BCAST:
    return("BROADCAST");
  default:
    return("?");
  }
}

void prziodata(APIziorecv *io)
{
int i,j;
IOdata *iod;
unsigned char aux,mask=1,ch=0,cur;
  
   while(mask){
    if(io->anchannel&mask)
      ch++;
    mask<<=1;
  }
  iod=&io->iodata;
  printf("%d samples, active digital channels: %02X %02x, analog channels: %02X\n",io->samples,io->digchannel[0],io->digchannel[1],io->anchannel);

  for(i=0;i<io->samples;i++){
    printf("\t");
    if(io->digchannel[1]|io->digchannel[0]){
      printf("I/O: %X%02X  ",iod->data[0]&1,iod->data[1]);
      iod++;
    }
    mask=1;
    cur=0;
    for(j=0;j<ch;j++){
      while(!(io->anchannel&mask)){
	mask<<=1;
	cur++;
	if(!mask)
	  break;
      }
      if(cur==7)
	printf("Vcc: %X%02X  ",iod->data[0]&3,iod->data[1]);
      else
	printf("AN%c: %X%02X  ",cur+'0',iod->data[0]&3,iod->data[1]);
      iod++;
      cur++;
      mask<<=1;
    }
    printf("\n");
  }
}


unsigned char *przdt(unsigned char zdt)
{
  switch(zdt){
  case ZID_DTCOORD:
    return("COORDINATOR");
  case ZID_DTROUTER:
    return("ROUTER");
  case ZID_DTENDDEV:
    return("END-DEVICE");
  default:
    return("Dev.Type=?");
  }
}


void prznodeid(APIznodeID *id)
{
APIznodeID1 *id1;
APIznodeID2 *id2;

        id1=&id->id1;
        prsaddr(id1->addr16);
	priaddr(id1->addr64);
	printf("\nNI: %s\n",&id1->ID);
	id2=(APIznodeID2 *) (&id1->ID+strlen(&id1->ID)+1);
	printf("Parent");
	prsaddr(id2->parent);
	printf("\tType: %s\tStatus: %02X\n",przdt(id2->type),id2->action);
	printf("ProfileID: ");
	prdata(&id2->profileID,2,1);
	printf("\tManufID: ");
	prdata(&id2->manufacturerID,2,1);
	printf("\n");

}
